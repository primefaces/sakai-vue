# Changelog

## [3.26.1](https://github.com/primefaces/primevue-sass-theme/tree/3.26.1) (2023-03-27)

**Fixed bugs:**

- Missing styles from PrimeVue v3.24.0 [\#3](https://github.com/primefaces/primevue-sass-theme/issues/3)

## [3.26.0](https://github.com/primefaces/primevue-sass-theme/tree/3.26.0) (2023-03-21)

- No changes, provides semantic versioning compatibility for PrimeVue 3.26.0

## [3.25.0](https://github.com/primefaces/primevue-sass-theme/tree/3.25.0) (2023-03-13)

- No changes, provides semantic versioning compatibility for PrimeVue 3.25.0

## [3.24.0](https://github.com/primefaces/primevue-sass-theme/tree/3.24.0) (2023-03-13)

- Initial release